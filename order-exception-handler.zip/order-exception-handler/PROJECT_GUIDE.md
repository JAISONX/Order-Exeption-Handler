# Order Exception Handler — Project Guide & Build Order

This file explains **what the project is** and **the exact order to write
the files in**, so the codebase grows the same way a senior engineer would
grow it: bottom-up, with each layer testable before the next one depends on
it. If you re-type this project yourself (recommended — typing it builds
the muscle memory you need for an interview whiteboard session), follow
this order. Don't skip ahead to the agents before the database works, and
don't touch the React frontend before the backend can serve real data.

---

## 1. What this project actually is

A new order comes in through a webhook. Two agents look at it **at the
same time**: one checks for fraud patterns, one checks inventory. If
either one raises a flag, a third agent drafts a customer email explaining
the hold or delay. The order's status moves through SQLite —
`received → checked → fulfilled / flagged / backordered` — and a live
dashboard shows all of this happening in real time, with anything flagged
visually pulled out for a human to review.

The reason this is a strong portfolio piece isn't "it calls an LLM three
times." It's that it demonstrates:

- **Real multi-agent orchestration** (LangGraph `StateGraph`, not a chain
  of `if/else` calling OpenAI three times)
- **Parallel execution with a fan-in barrier** — a graph-shape problem,
  not just business logic
- **Conditional branching based on agent output** — the graph itself
  decides whether the third agent even runs
- **Structured output** — every agent is forced to return validated JSON,
  not free text you regex out of a response
- **A real state machine persisted in a database**, not just an in-memory
  variable
- **Human-in-the-loop visibility** — a live ops dashboard, not a CLI print
  statement

## 2. The three layers, and why this order

Think of the whole project as three layers stacked on top of each other.
You always build a layer so it can be tested **before** the layer above it
exists, using nothing but `curl` or a Python shell — never trust "I'll
test it once the UI is done."

```
Layer 3:  React dashboard           (renders whatever Layer 2 sends it)
Layer 2:  FastAPI + LangGraph        (orchestrates agents, talks to Layer 1)
Layer 1:  SQLite + Pydantic models   (the ground truth, no logic, just shape)
```

You build Layer 1 first because nothing else can be tested without
somewhere to read/write data. You build the **agents before the graph**
that wires them together, because each agent is a small pure function you
can unit-test alone. You build the **graph before the API routes**, because
the route handler's only job is to call the already-working graph. You
build the **WebSocket plumbing right alongside the routes**, not after,
because retrofitting live updates onto a finished REST API is much more
annoying than building both together. The **React frontend is last**,
always — it's the easiest part to fake-test with `curl` until then, and
building it first means building against an API that doesn't exist yet.

---

## 3. Step-by-step build order

### Step 1 — `backend/requirements.txt` and `backend/.env.example`

Decide your dependencies and your config keys before writing any code.
This forces you to think through what you'll actually need (FastAPI,
LangGraph, LangChain's OpenAI wrapper, aiosqlite, python-dotenv) instead
of discovering missing packages mid-build.

### Step 2 — `backend/app/config.py`

The **first real Python file**. One job: read environment variables once,
expose them as a `settings` object. Every other file imports `settings`
from here instead of calling `os.getenv()` directly — that's the whole
point of this file existing. Build this first because literally every
other module needs it (database path, OpenAI key, CORS origin).

### Step 3 — `backend/app/db/database.py`

The **ground truth layer**. Define the SQLite schema (the `orders` table
and the `agent_events` audit table), then write the CRUD functions:
`init_db`, `insert_order`, `update_order`, `get_order`, `list_orders`,
`log_agent_event`, `get_agent_events`.

**Test this file alone before moving on.** Open a Python shell, call
`init_db()`, insert a fake order, read it back. If this doesn't work in
isolation, nothing built on top of it will either.

### Step 4 — `backend/app/models/schemas.py` and `backend/app/models/state.py`

Two different "shapes" that look similar but serve different jobs:

- `schemas.py` = Pydantic models = **what crosses the network** (the
  webhook payload coming in, the order JSON going out to the frontend).
- `state.py` = a `TypedDict` = **what flows between LangGraph nodes**
  inside a single pipeline run.

Write both now, before any agent or route exists, because both the agents
(Step 5) and the API (Step 7) need to import them.

### Step 5 — The three agents, one at a time

Build and reason about these **independently** — each is just an async
function that takes a state dict and returns a partial update. Don't wire
them together yet.

1. `backend/app/agents/llm_client.py` — one shared `ChatOpenAI` instance.
2. `backend/app/agents/fraud_agent.py` — takes order data, returns
   `{fraud_flag, fraud_reason}`. Includes a deterministic mock fallback
   for when there's no API key yet.
3. `backend/app/agents/inventory_agent.py` — same shape, returns
   `{inventory_flag, inventory_reason, backorder_eta}`.
4. `backend/app/agents/comms_agent.py` — takes whatever the other two
   agents wrote into state, returns `{customer_email_draft}`.

At this point you could call `run_fraud_check(fake_state)` directly in a
Python shell and get a real answer back. That's the test. Don't move to
Step 6 until you've actually done that for all three.

### Step 6 — `backend/app/graph/workflow.py`

Now, and only now, wire the three already-working agents into a
`StateGraph`: fan-out from `START` to `fraud_check` and `inventory_check`
in parallel, fan-in through a `join_and_finalize` node (which also decides
the order's final status), then a conditional edge that routes to
`customer_comms` only if something was flagged. Compile the graph once at
import time.

**Test this in isolation too** — call `order_graph.ainvoke(fake_state)`
from a script and look at what comes back, before any FastAPI route
touches it.

### Step 7 — WebSocket plumbing + REST routes, together

1. `backend/app/api/ws_manager.py` — a `ConnectionManager` class that
   tracks connected clients and broadcasts JSON to all of them.
2. `backend/app/api/events.py` — a thin wrapper so agents can log an event
   to the database **and** broadcast it live, without agents needing to
   know WebSockets exist. Go back and point each agent's logging calls at
   this wrapper instead of the raw database function.
3. `backend/app/api/routes.py` — the webhook endpoint (insert order,
   kick off the graph as a background task, broadcast updates as they
   happen) plus the simple `GET` endpoints for listing orders and
   fetching an order's agent trace.

### Step 8 — `backend/app/main.py`

Tie it all together: FastAPI app, CORS middleware, the lifespan handler
that calls `init_db()` on startup, `app.include_router(...)`, and the
`/ws/orders` WebSocket endpoint. This file should be short — almost
everything it touches was already built and tested in earlier steps.

**Now run it**: `uvicorn app.main:app --reload --port 8000`. Hit
`/api/health` in a browser. POST a fake order to `/api/orders/webhook`
with `curl` and watch the terminal logs as the graph runs.

### Step 9 — `backend/app/seed.py`

A script that POSTs a handful of realistic demo orders to your now-working
webhook endpoint. Write this once Step 8 is confirmed working — its entire
job is to exercise the real pipeline repeatedly so you have data to look
at before the frontend exists.

### Step 10 — Frontend foundation: `package.json`, `vite.config.js`, `index.html`, `src/index.css`, `src/main.jsx`

Standard Vite + React scaffolding, plus your design tokens (colors, fonts)
in one global CSS file so every component below references the same
palette instead of hardcoding colors per-component.

### Step 11 — `src/lib/api.js`

Three small `fetch` wrappers (`fetchOrders`, `fetchOrderEvents`,
`submitOrderWebhook`). Build this before any component, because every
component that needs data calls through here — never `fetch()` directly
inside a component.

### Step 12 — `src/hooks/useOrdersSocket.js`

The data layer for the whole dashboard: fetches existing orders once on
load, opens the WebSocket, and keeps an in-memory `orders` array in sync
with every `order_created` / `order_updated` / `agent_event` message.
Nothing renders yet — this hook just needs to work, which you can confirm
with a one-line test component that just dumps the hook's output to the
screen as text.

### Step 13 — The components, smallest and most isolated first

1. `StatsBar.jsx` — pure function of an `orders` array, no children, no
   state of its own. Easiest possible component to get right first.
2. `OrderCard.jsx` — renders one order, takes the live-agent indicator as
   a prop. Still no internal state.
3. `PipelineBoard.jsx` — groups orders into columns and renders an
   `OrderCard` per order. Depends on Step 13.2 existing.
4. `NewOrderForm.jsx` — the only component with real form state; calls
   `submitOrderWebhook` from Step 11.
5. `AgentTrace.jsx` — fetches an order's event history itself
   (`fetchOrderEvents`) and appends live events as they arrive.
6. `OrderDetailDrawer.jsx` — the slide-in panel that composes
   `AgentTrace` plus the order's full details. Built last among the
   components because it depends on Step 13.5.

### Step 14 — `src/App.jsx`

The thinnest file in the whole frontend on purpose: call the hook from
Step 12, hold one piece of local state (which order is selected), and
wire the components from Step 13 together. If `App.jsx` ever starts
growing real logic, that logic belongs in a hook or a component instead.

### Step 15 — Run both halves together

```bash
# terminal 1
cd backend && uvicorn app.main:app --reload --port 8000

# terminal 2
cd frontend && npm install && npm run dev

# terminal 3 — once both are running
cd backend && python -m app.seed
```

Watch `localhost:5173`. Orders should appear, move across the columns,
and the agent dots on each card should pulse while a check is in flight.

---

## 4. The one rule that keeps this order from collapsing

**Never write code in a layer until the layer below it has been manually
tested on its own.** Database functions tested with a plain Python shell.
Agents tested by calling them directly with a fake state dict. The graph
tested with `ainvoke()` and no FastAPI involved. The API tested with
`curl` and no React involved. By the time you open the browser, every
piece underneath it has already been proven to work — so if something
breaks, you know it's almost certainly in the wiring you just added, not
buried three layers down.

# Order Exception Handler

A multi-agent order-processing pipeline built to demonstrate agentic AI
architecture for a GenAI/Agentic AI developer portfolio.

A new order webhook arrives → a **Fraud-check agent** and an **Inventory
agent** evaluate it **in parallel** → if either raises a flag, a
**Customer-comms agent** drafts an explanatory email → the order's
lifecycle status updates in SQLite → an ops dashboard shows the live
pipeline over a WebSocket, with exceptions highlighted for human review.

## Why this project demonstrates agentic AI skills

- **Multi-agent orchestration with LangGraph**: a real `StateGraph` with
  parallel fan-out (fraud + inventory run concurrently), a join/barrier
  node, and a conditional edge that skips an entire agent when it isn't
  needed — not just a linear `if/else` chain pretending to be "agents."
- **Structured LLM output**: every agent forces the model to return a
  validated Pydantic schema (`with_structured_output`), so the pipeline
  never has to parse free-form text out of an LLM response.
- **Human-in-the-loop design**: exceptions are surfaced, not hidden —
  the dashboard exists specifically to make agent decisions reviewable.
- **Live system observability**: a WebSocket pushes every agent
  start/complete/error event to the frontend in real time, so you can
  *watch* the multi-agent system think.
- **Mock mode**: the entire pipeline runs convincingly without an OpenAI
  key (deterministic heuristic fallbacks), so the project is demoable
  anywhere instantly.

## Architecture

```
order-exception-handler/
├── backend/
│   ├── app/
│   │   ├── main.py              FastAPI app, lifespan, WebSocket route
│   │   ├── config.py            Centralized env/config loading
│   │   ├── seed.py               Demo data generator (hits the real webhook)
│   │   ├── db/
│   │   │   └── database.py      SQLite schema + all queries (aiosqlite)
│   │   ├── models/
│   │   │   ├── schemas.py        Pydantic API request/response contracts
│   │   │   └── state.py          LangGraph shared state (TypedDict)
│   │   ├── agents/
│   │   │   ├── llm_client.py     Shared ChatOpenAI client
│   │   │   ├── fraud_agent.py    Fraud-check agent node
│   │   │   ├── inventory_agent.py Inventory agent node
│   │   │   └── comms_agent.py    Customer-comms agent node
│   │   ├── graph/
│   │   │   └── workflow.py       The LangGraph StateGraph definition
│   │   └── api/
│   │       ├── routes.py         REST endpoints (webhook, list, events)
│   │       ├── ws_manager.py     WebSocket connection manager
│   │       └── events.py         Bridges agent events -> DB + WebSocket
│   ├── requirements.txt
│   └── .env.example
└── frontend/
    └── src/
        ├── components/
        │   ├── StatsBar.jsx          Top summary bar
        │   ├── NewOrderForm.jsx      Buttons to simulate webhooks
        │   ├── PipelineBoard.jsx     Column-per-status board
        │   ├── OrderCard.jsx         Individual order card + live agent dots
        │   ├── OrderDetailDrawer.jsx Slide-in detail panel
        │   └── AgentTrace.jsx        Per-order agent audit log
        ├── hooks/
        │   └── useOrdersSocket.js    WebSocket + REST data layer
        ├── lib/api.js                REST fetch helpers
        ├── App.jsx
        └── main.jsx
```

### The LangGraph workflow

```
                    ┌──────────────┐
              ┌────▶│ fraud_check  │────┐
              │     └──────────────┘    │
    START ────┤                         ├──▶ join_and_finalize ──┬─▶ customer_comms ──▶ END
              │     ┌──────────────┐    │      (barrier node)    │
              └────▶│  inventory   │────┘                        └────────────────────▶ END
                    └──────────────┘
```

`fraud_check` and `inventory_check` run **in parallel** — LangGraph starts
both the instant `START` fires. `join_and_finalize` is a real node with
two incoming edges, so LangGraph will not run it until **both** agents
have written their results — that's the fan-in barrier. From there, a
conditional edge skips `customer_comms` entirely unless one of the two
agents actually raised a flag.

## Setup

### 1. Backend

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# Edit .env and paste your OpenAI key into OPENAI_API_KEY.
# (You can skip this -- see "Running without an OpenAI key" below.)

uvicorn app.main:app --reload --port 8000
```

The API is now running at `http://localhost:8000`. Visit
`http://localhost:8000/api/health` to confirm it's up.

### 2. Frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173` — you'll see an empty pipeline board and a
"Live" indicator once the WebSocket connects.

### 3. Generate demo orders

In a third terminal, with the backend already running:

```bash
cd backend
source .venv/bin/activate
python -m app.seed
```

This sends five realistic orders straight to the webhook endpoint, one
every 1.5 seconds, so you can watch them animate through the pipeline.
You can also click the **"Simulate a webhook"** buttons directly in the
dashboard UI instead.

## Running without an OpenAI key

If `OPENAI_API_KEY` is left unset (or still the placeholder value from
`.env.example`), every agent automatically falls back to a deterministic,
rule-based mock implementation that mirrors the same logic given to the
LLM in its prompt. The dashboard, WebSocket updates, and SQLite state
machine all work identically either way — only the source of the
fraud/inventory judgment and email wording changes. This is useful for
demoing the **architecture** without needing to spend API credits, and
it's also why the agent files are written with the LLM call and the mock
fallback living side-by-side, not in separate code paths a recruiter would
have to dig for.

## Talking points for interviews

- **Why parallel fan-out instead of sequential agents**: fraud and
  inventory checks are independent of each other's output, so running
  them concurrently with LangGraph halves the latency contributed by
  those two steps versus a naive sequential chain — worth being able to
  explain *why* the graph is shaped the way it is, not just that it works.
- **Why a dedicated join node instead of attaching the conditional logic
  directly to both parallel edges**: it guarantees the "wait for both
  agents, then decide once" semantics unambiguously, rather than relying
  on subtler framework behavior.
- **Why structured output instead of prompting for JSON and parsing it
  yourself**: reliability. An agent pipeline that writes directly to a
  database cannot tolerate the LLM occasionally wrapping its JSON in
  prose or markdown fences.
- **Why background tasks for the webhook handler**: a real webhook
  sender expects a fast response and will retry on timeout -- you can't
  make it wait on 2-3 LLM calls synchronously.
- **Why aiosqlite instead of sqlite3**: the FastAPI app is async
  end-to-end (WebSocket + concurrent LangGraph nodes); a blocking DB
  driver would freeze every connected dashboard during each query.

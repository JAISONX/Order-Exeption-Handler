"""
Customer-comms agent.

Job: ONLY runs if the fraud agent or the inventory agent raised a flag
(see the conditional edge in workflow.py — this node is not even reached
otherwise). Drafts a short, human-readable email explaining the hold or
delay to the customer, using whichever flag(s) fired as context.
"""

from pydantic import BaseModel, Field
from app.agents.llm_client import get_llm
from app.models.state import OrderState
from app.api.events import log_and_broadcast_event
from app.config import settings


class EmailDraft(BaseModel):
    subject: str = Field(description="Short, clear email subject line")
    body: str = Field(description="The full email body, friendly and concise")


SYSTEM_PROMPT = """You are a customer-communications agent for an \
e-commerce company. An order has been placed on hold or delayed, and you \
must draft a short, warm, honest email to the customer explaining the \
situation in plain language.

Tone rules:
- Be warm and apologetic without being obsequious.
- NEVER mention the word "fraud" or imply the customer did anything wrong \
— if a fraud review is the cause, phrase it neutrally as "we're completing \
a routine verification on your order."
- If it's an inventory/backorder issue, be upfront about the delay and give \
the ETA if one was provided.
- Keep the body under 120 words.
- Sign off as "The Orders Team".
Respond ONLY through the structured schema you've been given."""


def _build_mock_draft(state: OrderState) -> EmailDraft:
    """Mock-mode fallback — template-based but still personalized per
    order, so the dashboard has real-looking content with no API key."""
    name = state["customer_name"].split(" ")[0]  # first name only, friendlier
    if state.get("inventory_flag"):
        eta = state.get("backorder_eta") or "a little longer than usual"
        body = (
            f"Hi {name},\n\nThanks for your order! A couple of items are "
            f"temporarily out of stock, so your order will ship in {eta}. "
            f"We'll notify you the moment it's on its way.\n\n"
            f"We appreciate your patience.\n\nThe Orders Team"
        )
        subject = "A quick update on your order"
    else:
        body = (
            f"Hi {name},\n\nThanks for your order! We're completing a "
            f"routine verification on your order before it ships — this is "
            f"a standard check and no action is needed from you right now. "
            f"You'll get a shipping confirmation shortly.\n\n"
            f"The Orders Team"
        )
        subject = "Your order is being processed"
    return EmailDraft(subject=subject, body=body)


async def run_customer_comms(state: OrderState) -> dict:
    """
    LangGraph node. Notice this function has NO knowledge of whether it's
    "allowed" to run — that decision was already made by the conditional
    edge that routed execution here. By the time this code runs, the
    answer to "should comms happen" is already yes; this function's only
    job is HOW to draft the message.
    """
    order_id = state["order_id"]
    await log_and_broadcast_event(order_id, "comms", "started", "Drafting customer email")

    context = {
        "customer_name": state["customer_name"],
        "fraud_flag": state.get("fraud_flag", False),
        "fraud_reason": state.get("fraud_reason"),
        "inventory_flag": state.get("inventory_flag", False),
        "inventory_reason": state.get("inventory_reason"),
        "backorder_eta": state.get("backorder_eta"),
    }

    try:
        if settings.has_openai_key:
            llm = get_llm()
            structured_llm = llm.with_structured_output(EmailDraft)
            draft: EmailDraft = await structured_llm.ainvoke(
                [
                    ("system", SYSTEM_PROMPT),
                    ("human", f"Order context:\n{context}"),
                ]
            )
        else:
            draft = _build_mock_draft(state)

        await log_and_broadcast_event(
            order_id, "comms", "completed", f"Drafted email: '{draft.subject}'"
        )

        formatted = f"Subject: {draft.subject}\n\n{draft.body}"
        return {"customer_email_draft": formatted}

    except Exception as exc:
        await log_and_broadcast_event(order_id, "comms", "error", str(exc))
        return {
            "customer_email_draft": (
                "Subject: Update on your order\n\n"
                "We're reviewing your order and will follow up shortly. "
                "(Auto-draft failed — needs manual email.)"
            )
        }

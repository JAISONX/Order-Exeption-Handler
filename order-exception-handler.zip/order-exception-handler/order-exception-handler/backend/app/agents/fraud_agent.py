"""
Fraud-check agent.

Job: look at one order's shape (amount, item mix, shipping destination,
customer info) and decide whether it LOOKS suspicious enough to hold for
human review. This is intentionally a heuristics-plus-LLM-judgment agent,
not a real fraud model — the point of this project is demonstrating
agent orchestration, not building production fraud detection.
"""

import json
from pydantic import BaseModel, Field
from app.agents.llm_client import get_llm
from app.models.state import OrderState
from app.api.events import log_and_broadcast_event
from app.config import settings


class FraudVerdict(BaseModel):
    """
    The exact JSON shape we force the LLM to return, via
    with_structured_output(). Pydantic validates the LLM's output against
    this automatically — if the model tries to return is_suspicious as the
    string "yes" instead of a bool, this raises a validation error rather
    than silently corrupting our database.
    """

    is_suspicious: bool = Field(
        description="True if this order shows patterns associated with fraud"
    )
    reason: str = Field(
        description="One short sentence explaining the verdict, for a human reviewer"
    )


# Few-shot-style instruction prompt. We spell out the SPECIFIC heuristics
# instead of just saying "detect fraud" because LLMs are much more
# consistent when given concrete criteria to check against rather than an
# open-ended judgment call.
SYSTEM_PROMPT = """You are a fraud-detection agent for an e-commerce order \
pipeline. You receive ONE order's details and must decide if it shows \
patterns commonly associated with fraudulent or risky orders.

Flag an order as suspicious if you see things like:
- An unusually high total order value (over $1500) for typical retail goods.
- A large quantity of the same single high-value item (bulk reselling pattern).
- A mismatch between the customer's name/email domain and the shipping \
country that seems inconsistent (use judgment, do not be overly strict).
- Shipping to a country commonly associated with high chargeback rates \
combined with a high order value.

Do NOT flag normal, modest orders just because they have multiple items. \
Most orders are legitimate — only flag genuine red flags, not vague unease. \
Respond ONLY through the structured schema you've been given."""


def _build_mock_verdict(order: dict) -> FraudVerdict:
    """
    Deterministic stand-in used when no OpenAI key is configured, so the
    whole pipeline (and the dashboard) is demoable out of the box. Uses the
    same heuristic spirit as the prompt above, just hard-coded in Python.
    """
    high_value = order["total_amount"] > 1500
    bulk_single_item = any(item["quantity"] >= 10 for item in order["items"])
    if high_value or bulk_single_item:
        reason = (
            "Order total exceeds $1500"
            if high_value
            else "Bulk quantity of a single item suggests reselling"
        )
        return FraudVerdict(is_suspicious=True, reason=reason)
    return FraudVerdict(is_suspicious=False, reason="No suspicious patterns detected")


async def run_fraud_check(state: OrderState) -> dict:
    """
    The actual LangGraph node function. LangGraph calls this with the
    current state and expects a dict of the fields THIS node is updating.

    Signature shape (state in, partial dict out) is the LangGraph contract
    for every node — keep this in mind, every agent file follows it.
    """
    order_id = state["order_id"]
    await log_and_broadcast_event(order_id, "fraud", "started", "Evaluating order risk")

    order_summary = {
        "total_amount": state["total_amount"],
        "items": state["items"],
        "shipping_country": state["shipping_country"],
        "customer_email": state["customer_email"],
    }

    try:
        if settings.has_openai_key:
            llm = get_llm()
            # with_structured_output binds our Pydantic schema to this call
            # only — it returns a NEW model instance, doesn't mutate `llm`.
            structured_llm = llm.with_structured_output(FraudVerdict)
            verdict: FraudVerdict = await structured_llm.ainvoke(
                [
                    ("system", SYSTEM_PROMPT),
                    ("human", f"Order details:\n{json.dumps(order_summary, indent=2)}"),
                ]
            )
        else:
            verdict = _build_mock_verdict(order_summary)

        await log_and_broadcast_event(
            order_id,
            "fraud",
            "completed",
            f"suspicious={verdict.is_suspicious} — {verdict.reason}",
        )

        # This is the partial-update dict LangGraph merges into shared state.
        # We do NOT return order_id/items/etc — only what THIS node owns.
        return {
            "fraud_flag": verdict.is_suspicious,
            "fraud_reason": verdict.reason,
        }

    except Exception as exc:
        # An agent failing should never crash the whole order pipeline.
        # We log it and fail "safe" by flagging for human review — silently
        # passing a fraud check because the LLM call errored would be the
        # worse failure mode.
        await log_and_broadcast_event(order_id, "fraud", "error", str(exc))
        return {
            "fraud_flag": True,
            "fraud_reason": f"Fraud check failed to complete ({exc}); flagged for manual review",
        }

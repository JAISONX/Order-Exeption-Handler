"""
Inventory agent.

Job: for each line item in the order, check (simulated) stock levels and
decide whether the whole order can be fulfilled immediately, or whether
any item needs to be backordered. Runs in PARALLEL with the fraud agent
(see workflow.py) since neither needs the other's output.
"""

import json
import random
from pydantic import BaseModel, Field
from app.agents.llm_client import get_llm
from app.models.state import OrderState
from app.api.events import log_and_broadcast_event
from app.config import settings


class InventoryVerdict(BaseModel):
    can_fulfill: bool = Field(
        description="True only if every item can be shipped immediately"
    )
    reason: str = Field(description="One short sentence explaining the decision")
    eta: str | None = Field(
        default=None,
        description="If backordered, a short human-readable ETA like '5-7 business days'. Null if fulfillable now.",
    )


SYSTEM_PROMPT = """You are an inventory-fulfillment agent for an e-commerce \
order pipeline. You are given a simulated stock snapshot for each SKU in an \
order. Decide whether the order can be fulfilled immediately.

Rules:
- If every item's requested quantity is LESS THAN OR EQUAL TO its available \
stock, the order can be fulfilled now.
- If ANY item's requested quantity EXCEEDS its available stock, the whole \
order must be backordered, even if other items are in stock (we ship \
orders as a single shipment in this business).
- When backordering, give a realistic short ETA based on how large the \
shortfall is (small shortfall -> a few days, large shortfall -> 1-2 weeks).
Respond ONLY through the structured schema you've been given."""


def _simulate_stock_snapshot(items: list[dict]) -> list[dict]:
    """
    There's no real warehouse here, so we deterministically *simulate* a
    stock level per SKU using a seeded random number generator. Seeding
    with the SKU string means the SAME sku always gets the SAME simulated
    stock within one process run — important so re-rendering an order in
    the UI doesn't show inventory magically changing on every refresh.
    """
    snapshot = []
    for item in items:
        rng = random.Random(item["sku"])  # seeded per-SKU, not global random
        available_stock = rng.randint(0, 50)
        snapshot.append(
            {
                "sku": item["sku"],
                "name": item["name"],
                "requested_quantity": item["quantity"],
                "available_stock": available_stock,
            }
        )
    return snapshot


def _build_mock_verdict(stock_snapshot: list[dict]) -> InventoryVerdict:
    """Mock-mode fallback mirroring the LLM's instructed rules exactly,
    so behavior is consistent whether or not an API key is configured."""
    shortfalls = [
        s for s in stock_snapshot if s["requested_quantity"] > s["available_stock"]
    ]
    if not shortfalls:
        return InventoryVerdict(
            can_fulfill=True, reason="All items in stock", eta=None
        )
    worst_gap = max(s["requested_quantity"] - s["available_stock"] for s in shortfalls)
    eta = "5-7 business days" if worst_gap <= 5 else "1-2 weeks"
    skus = ", ".join(s["sku"] for s in shortfalls)
    return InventoryVerdict(
        can_fulfill=False,
        reason=f"Insufficient stock for: {skus}",
        eta=eta,
    )


async def run_inventory_check(state: OrderState) -> dict:
    """LangGraph node: same (state in, partial dict out) contract as the
    fraud agent. Runs concurrently with run_fraud_check — see workflow.py."""
    order_id = state["order_id"]
    await log_and_broadcast_event(order_id, "inventory", "started", "Checking stock levels")

    stock_snapshot = _simulate_stock_snapshot(state["items"])

    try:
        if settings.has_openai_key:
            llm = get_llm()
            structured_llm = llm.with_structured_output(InventoryVerdict)
            verdict: InventoryVerdict = await structured_llm.ainvoke(
                [
                    ("system", SYSTEM_PROMPT),
                    (
                        "human",
                        f"Stock snapshot:\n{json.dumps(stock_snapshot, indent=2)}",
                    ),
                ]
            )
        else:
            verdict = _build_mock_verdict(stock_snapshot)

        await log_and_broadcast_event(
            order_id,
            "inventory",
            "completed",
            f"can_fulfill={verdict.can_fulfill} — {verdict.reason}",
        )

        return {
            # inventory_flag mirrors "needs human attention", same polarity
            # as fraud_flag, so the graph's router (see workflow.py) can
            # treat both flags identically with one simple OR check.
            "inventory_flag": not verdict.can_fulfill,
            "inventory_reason": verdict.reason,
            "backorder_eta": verdict.eta,
        }

    except Exception as exc:
        await log_and_broadcast_event(order_id, "inventory", "error", str(exc))
        return {
            "inventory_flag": True,
            "inventory_reason": f"Inventory check failed to complete ({exc}); flagged for manual review",
            "backorder_eta": None,
        }

"""
Shared helper for calling OpenAI via LangChain's ChatOpenAI wrapper.

Why go through LangChain's ChatOpenAI rather than the raw `openai` SDK:
LangGraph nodes are just async functions, but using LangChain's chat model
class gives us .with_structured_output(), which forces the model to return
JSON matching a Pydantic schema instead of free text we'd have to parse
ourselves with regex/json.loads and hope it doesn't break. That reliability
matters a lot for an agent pipeline that writes structured fields to a
database — we cannot have the LLM occasionally return prose instead of JSON.
"""

from langchain_openai import ChatOpenAI
from app.config import settings

_llm_instance: ChatOpenAI | None = None


def get_llm() -> ChatOpenAI:
    """
    Lazily construct a single shared ChatOpenAI client (module-level
    singleton) rather than creating a new client per agent call. Creating
    the client is cheap, but sharing one instance is the conventional
    pattern and avoids accidentally holding many idle HTTP connection pools
    open if this app scales to handling many orders concurrently.
    """
    global _llm_instance
    if _llm_instance is None:
        _llm_instance = ChatOpenAI(
            model=settings.OPENAI_MODEL,
            api_key=settings.OPENAI_API_KEY,
            temperature=0,  # deterministic-ish outputs; this is a back-office
            # decisioning pipeline, not creative writing — we want the same
            # order to get the same fraud/inventory verdict if re-run.
            timeout=30,
        )
    return _llm_instance

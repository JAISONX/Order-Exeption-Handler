"""
Thin bridge between agent logic and the live dashboard.

Why this file exists instead of just calling db.log_agent_event directly
and separately calling manager.broadcast wherever needed: agents should
not need to know that a WebSocket layer exists at all (that's a transport
detail, agents are business logic). And the db module should not import
the WebSocket manager either (that would make a persistence module depend
on a network layer, backwards from how dependencies should flow). This
module sits in between: it knows about both, so neither of THEM has to.
"""

from app.db import database as db
from app.api.ws_manager import manager


async def log_and_broadcast_event(
    order_id: str, agent_name: str, event_type: str, detail: str = ""
) -> None:
    """
    Every agent calls THIS function (not db.log_agent_event directly) so
    that every step an agent takes — "fraud check started", "inventory
    check completed", etc — shows up on the dashboard the moment it
    happens, not just once the whole graph finishes. This is what makes
    the UI feel like it's watching agents think in real time instead of
    just flashing a final result.
    """
    await db.log_agent_event(order_id, agent_name, event_type, detail)
    await manager.broadcast(
        {
            "type": "agent_event",
            "payload": {
                "order_id": order_id,
                "agent_name": agent_name,
                "event_type": event_type,
                "detail": detail,
            },
        }
    )

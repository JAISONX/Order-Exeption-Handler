"""
REST API routes.

Three real endpoints:
  POST /api/orders/webhook   -> receives a new order, kicks off the graph
  GET  /api/orders            -> list orders for the dashboard's initial load
  GET  /api/orders/{id}/events -> agent trace for one order (the AgentTrace panel)

The WebSocket endpoint lives in main.py (it needs the raw FastAPI `app`
object directly, so it's wired up there rather than through this router).
"""

import uuid
from fastapi import APIRouter, HTTPException, BackgroundTasks
from app.models.schemas import OrderWebhookPayload, OrderOut, AgentEventOut
from app.db import database as db
from app.graph.workflow import order_graph
from app.api.ws_manager import manager

router = APIRouter(prefix="/api/orders", tags=["orders"])


async def _process_order(order_id: str) -> None:
    """
    Runs the LangGraph pipeline for one order and persists/broadcasts the
    result. Pulled into its own function (rather than inlined in the route
    handler) because it's launched as a FastAPI BackgroundTask — see the
    webhook handler below — which means the HTTP response returns to the
    caller immediately while this keeps running. That matters here because
    a real webhook sender (e.g. Shopify) expects a fast 200 OK and will
    retry if your endpoint hangs waiting on multiple LLM calls.
    """
    order = await db.get_order(order_id)
    if order is None:
        return  # order was somehow not persisted; nothing to process

    # Move to 'checked' immediately so the dashboard shows the order
    # actively being worked on, before any agent has finished.
    await db.update_order(order_id, {"status": "checked"})
    await manager.broadcast(
        {"type": "order_updated", "payload": await db.get_order(order_id)}
    )

    # Build the initial LangGraph state from the persisted order. Only the
    # "input" fields are populated; everything the agents will write
    # (fraud_flag, inventory_flag, etc.) is left absent here — LangGraph
    # doesn't require every TypedDict key to be present up front.
    initial_state = {
        "order_id": order["id"],
        "customer_name": order["customer_name"],
        "customer_email": order["customer_email"],
        "items": order["items"],
        "total_amount": order["total_amount"],
        "shipping_country": order["shipping_country"],
    }

    # This single call runs the ENTIRE graph: fraud_check and
    # inventory_check in parallel, then join_and_finalize, then
    # conditionally customer_comms. `ainvoke` returns the final merged
    # state once the graph reaches END.
    final_state = await order_graph.ainvoke(initial_state)

    # Persist everything the graph produced in one update.
    await db.update_order(
        order_id,
        {
            "status": final_state.get("final_status", "flagged"),
            "fraud_flag": int(final_state.get("fraud_flag", False)),
            "fraud_reason": final_state.get("fraud_reason"),
            "inventory_flag": int(final_state.get("inventory_flag", False)),
            "inventory_reason": final_state.get("inventory_reason"),
            "backorder_eta": final_state.get("backorder_eta"),
            "customer_email_draft": final_state.get("customer_email_draft"),
        },
    )

    updated_order = await db.get_order(order_id)
    await manager.broadcast({"type": "order_updated", "payload": updated_order})


@router.post("/webhook", response_model=OrderOut, status_code=201)
async def receive_order_webhook(
    payload: OrderWebhookPayload, background_tasks: BackgroundTasks
):
    """
    Simulates an inbound webhook from an e-commerce platform. FastAPI has
    already validated `payload` against OrderWebhookPayload by the time
    this function body runs — any malformed request never reaches here.
    """
    order_id = f"ord_{uuid.uuid4().hex[:10]}"

    order_dict = {
        "id": order_id,
        "customer_name": payload.customer_name,
        "customer_email": payload.customer_email,
        "items": [item.model_dump() for item in payload.items],
        "total_amount": payload.total_amount,
        "shipping_country": payload.shipping_country.upper(),
    }
    await db.insert_order(order_dict)

    created_order = await db.get_order(order_id)
    # Broadcast immediately so the dashboard shows the new order the
    # instant it lands, in the 'received' state, before any processing.
    await manager.broadcast({"type": "order_created", "payload": created_order})

    # Hand off the actual agent pipeline to a background task. This is
    # what lets us return a 201 response right away instead of making the
    # webhook caller wait for 2-3 sequential/parallel LLM calls.
    background_tasks.add_task(_process_order, order_id)

    return created_order


@router.get("", response_model=list[OrderOut])
async def get_orders(limit: int = 100):
    """Initial data load for the dashboard on page refresh/first connect.
    After this, the WebSocket carries all subsequent updates — the
    frontend does not poll this endpoint repeatedly."""
    return await db.list_orders(limit=limit)


@router.get("/{order_id}", response_model=OrderOut)
async def get_order_detail(order_id: str):
    order = await db.get_order(order_id)
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return order


@router.get("/{order_id}/events", response_model=list[AgentEventOut])
async def get_order_events(order_id: str):
    """Powers the AgentTrace panel — the step-by-step log of what each
    agent did for this specific order."""
    order = await db.get_order(order_id)
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return await db.get_agent_events(order_id)

"""
WebSocket connection manager.

Why this exists as its own class: FastAPI gives you one WebSocket object
per connected client, but our agents/graph code has no direct reference to
any specific client's socket (and shouldn't — that would tightly couple
business logic to the transport layer). Instead, the graph/agents call
`manager.broadcast(...)` and this manager fans that message out to EVERY
currently-connected dashboard, regardless of how many tabs/users are
watching. This is the standard pub/sub-lite pattern for a single-process
FastAPI app.
"""

from fastapi import WebSocket
import asyncio


class ConnectionManager:
    def __init__(self):
        # Plain list, not a set: WebSocket objects aren't guaranteed
        # hashable in a way we want to rely on, and connection counts here
        # are small (a handful of dashboard tabs), so O(n) removal is fine.
        self._connections: list[WebSocket] = []
        # Guards _connections against concurrent mutation — multiple
        # clients can connect/disconnect at the same moment an agent run
        # is broadcasting, and list mutation during iteration is exactly
        # the kind of race condition asyncio doesn't protect you from for
        # free.
        self._lock = asyncio.Lock()

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        async with self._lock:
            self._connections.append(websocket)

    async def disconnect(self, websocket: WebSocket) -> None:
        async with self._lock:
            if websocket in self._connections:
                self._connections.remove(websocket)

    async def broadcast(self, message: dict) -> None:
        """
        Send `message` (already a plain dict, JSON-serializable) to every
        connected client. We snapshot the connection list before iterating
        so that a client disconnecting mid-broadcast can't mutate the list
        we're actively looping over.
        """
        async with self._lock:
            targets = list(self._connections)

        dead: list[WebSocket] = []
        for ws in targets:
            try:
                await ws.send_json(message)
            except Exception:
                # A send failing means that socket is dead (client closed
                # the tab, network dropped, etc). We collect it here rather
                # than removing mid-loop, then clean up afterward.
                dead.append(ws)

        if dead:
            async with self._lock:
                for ws in dead:
                    if ws in self._connections:
                        self._connections.remove(ws)


# One shared instance for the whole app — imported by both the WebSocket
# route (to register new connections) and anywhere that needs to push a
# live update (the webhook handler, after each graph step).
manager = ConnectionManager()

"""
Centralized configuration.

Why this file exists: every other module imports `settings` from here instead
of calling os.getenv() directly. That means there is exactly ONE place that
knows how to read the environment, which makes the app testable (you can
monkeypatch `settings` in tests) and makes it obvious to a reviewer where
config comes from.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# BASE_DIR = the `backend/` folder, regardless of where the process is
# launched from. We compute it from this file's location rather than using
# a relative path like "./.env", because relative paths break the moment
# someone runs `uvicorn app.main:app` from a different working directory.
BASE_DIR = Path(__file__).resolve().parent.parent

# Load the .env file that sits next to requirements.txt. override=False
# (the default) means real environment variables (e.g. set by Docker or a
# cloud host) always win over the .env file, which is the behavior you want
# in production.
load_dotenv(BASE_DIR / ".env")


class Settings:
    """
    Plain class instead of a dataclass/Pydantic BaseSettings on purpose:
    this is a small project and a plain class with properties is the
    easiest thing for an interviewer to read in 10 seconds. In a larger
    production system you'd reach for pydantic-settings instead.
    """

    # .get() with a default means the app can still BOOT without a key
    # (so you can demo the dashboard/UI), but any agent call that actually
    # needs OpenAI will fail loudly later. We never want a missing key to
    # silently no-op.
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    # Resolve the DB path relative to BASE_DIR so it always lands in
    # backend/data/orders.db no matter the working directory.
    DATABASE_PATH: str = str(BASE_DIR / os.getenv("DATABASE_PATH", "data/orders.db"))

    CORS_ORIGIN: str = os.getenv("CORS_ORIGIN", "http://localhost:5173")

    @property
    def has_openai_key(self) -> bool:
        """Used by agents to decide: call the real LLM, or run in mock mode."""
        return bool(self.OPENAI_API_KEY) and self.OPENAI_API_KEY != "sk-your-key-here"


# Single shared instance — imported everywhere as `from app.config import settings`.
settings = Settings()

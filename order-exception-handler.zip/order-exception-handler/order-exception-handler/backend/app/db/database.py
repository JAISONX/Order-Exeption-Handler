"""
SQLite persistence layer using aiosqlite (async SQLite driver).

Why async SQLite: the FastAPI app is async end-to-end (WebSocket, the
LangGraph nodes are async functions). If we used the regular synchronous
`sqlite3` module here, every DB call would block the event loop and freeze
ALL connected WebSocket clients for the duration of that query. aiosqlite
gives us the same SQL but via `await`, so the event loop stays free to serve
other clients while a query is in flight.
"""

import json
import aiosqlite
from datetime import datetime, timezone
from app.config import settings

# The five states described in the spec, modeled as a real SQL CHECK
# constraint rather than just "trusting" the Python code to only ever
# write valid strings. If a bug tried to write status='bogus', SQLite
# itself would reject it.
ORDER_STATES = ("received", "checked", "fulfilled", "flagged", "backordered")

SCHEMA = """
CREATE TABLE IF NOT EXISTS orders (
    id              TEXT PRIMARY KEY,
    customer_name   TEXT NOT NULL,
    customer_email  TEXT NOT NULL,
    items           TEXT NOT NULL,      -- JSON array, see schemas.py for shape
    total_amount    REAL NOT NULL,
    shipping_country TEXT NOT NULL,
    status          TEXT NOT NULL CHECK(status IN
                        ('received','checked','fulfilled','flagged','backordered')),
    fraud_flag      INTEGER NOT NULL DEFAULT 0,   -- 0/1 boolean
    fraud_reason    TEXT,
    inventory_flag  INTEGER NOT NULL DEFAULT 0,
    inventory_reason TEXT,
    backorder_eta   TEXT,
    customer_email_draft TEXT,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);

-- Append-only log of every agent step for an order. This is what powers
-- the "agent trace" panel in the UI (recruiters love seeing the reasoning
-- trail, it's the most "agentic AI" part of the whole project).
CREATE TABLE IF NOT EXISTS agent_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id    TEXT NOT NULL,
    agent_name  TEXT NOT NULL,          -- 'fraud' | 'inventory' | 'comms'
    event_type  TEXT NOT NULL,          -- 'started' | 'completed' | 'error'
    detail      TEXT,                   -- human-readable message
    created_at  TEXT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);
"""


async def get_connection() -> aiosqlite.Connection:
    """
    Open a fresh connection per call rather than sharing one global
    connection. aiosqlite connections aren't safe to share across concurrent
    coroutines doing writes, and with WebSockets + parallel LangGraph nodes
    we DO have concurrent writers. SQLite handles many short-lived
    connections fine for a project at this scale.
    """
    conn = await aiosqlite.connect(settings.DATABASE_PATH)
    # Without this, aiosqlite returns rows as plain tuples and you'd access
    # fields by position (row[0], row[1]...) which is unreadable and breaks
    # silently if a column is ever reordered. Row factory lets us do
    # row["status"] instead.
    conn.row_factory = aiosqlite.Row
    # WAL = Write-Ahead Logging. Default SQLite locks the entire file on
    # write. WAL lets reads happen concurrently with writes, which matters
    # here because the dashboard is constantly reading while agents write.
    await conn.execute("PRAGMA journal_mode=WAL;")
    return conn


async def init_db() -> None:
    """Called once at app startup (see main.py's lifespan handler)."""
    conn = await get_connection()
    try:
        await conn.executescript(SCHEMA)
        await conn.commit()
    finally:
        await conn.close()


def now_iso() -> str:
    """
    Single source of truth for timestamp formatting. timezone.utc is
    explicit (never rely on naive local-time datetimes in a backend —
    they break the moment this is deployed to a server in a different
    timezone than your laptop).
    """
    return datetime.now(timezone.utc).isoformat()


async def insert_order(order: dict) -> None:
    """Insert a brand-new order in the 'received' state."""
    conn = await get_connection()
    try:
        ts = now_iso()
        await conn.execute(
            """
            INSERT INTO orders (
                id, customer_name, customer_email, items, total_amount,
                shipping_country, status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                order["id"],
                order["customer_name"],
                order["customer_email"],
                json.dumps(order["items"]),  # list -> JSON string for storage
                order["total_amount"],
                order["shipping_country"],
                "received",
                ts,
                ts,
            ),
        )
        await conn.commit()
    finally:
        await conn.close()


async def update_order(order_id: str, fields: dict) -> None:
    """
    Generic partial update. Builds 'col = ?' fragments dynamically from
    whatever keys are passed in, so each agent node only has to say what
    IT changed instead of restating the entire row. `updated_at` is always
    bumped here, in one place, so no caller can forget to do it.
    """
    if not fields:
        return
    fields = {**fields, "updated_at": now_iso()}
    columns = ", ".join(f"{key} = ?" for key in fields)
    values = list(fields.values()) + [order_id]

    conn = await get_connection()
    try:
        await conn.execute(f"UPDATE orders SET {columns} WHERE id = ?", values)
        await conn.commit()
    finally:
        await conn.close()


async def get_order(order_id: str) -> dict | None:
    conn = await get_connection()
    try:
        cursor = await conn.execute("SELECT * FROM orders WHERE id = ?", (order_id,))
        row = await cursor.fetchone()
        return _row_to_dict(row) if row else None
    finally:
        await conn.close()


async def list_orders(limit: int = 100) -> list[dict]:
    """Most recently updated first — so the dashboard naturally shows
    activity at the top without the frontend having to sort anything."""
    conn = await get_connection()
    try:
        cursor = await conn.execute(
            "SELECT * FROM orders ORDER BY updated_at DESC LIMIT ?", (limit,)
        )
        rows = await cursor.fetchall()
        return [_row_to_dict(r) for r in rows]
    finally:
        await conn.close()


async def log_agent_event(
    order_id: str, agent_name: str, event_type: str, detail: str = ""
) -> None:
    """Write one row to the audit trail. Called by every agent node on
    entry and exit, which is how the AgentTrace UI component gets its data."""
    conn = await get_connection()
    try:
        await conn.execute(
            """
            INSERT INTO agent_events (order_id, agent_name, event_type, detail, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (order_id, agent_name, event_type, detail, now_iso()),
        )
        await conn.commit()
    finally:
        await conn.close()


async def get_agent_events(order_id: str) -> list[dict]:
    conn = await get_connection()
    try:
        cursor = await conn.execute(
            "SELECT * FROM agent_events WHERE order_id = ? ORDER BY id ASC",
            (order_id,),
        )
        rows = await cursor.fetchall()
        return [dict(r) for r in rows]
    finally:
        await conn.close()


def _row_to_dict(row: aiosqlite.Row) -> dict:
    """
    Convert a DB row into the JSON-friendly shape the API/WebSocket layer
    sends to the frontend: parse the `items` JSON string back into a real
    list, and turn the 0/1 integer flags into actual Python booleans so
    the React side never has to do `Boolean(fraud_flag)` itself.
    """
    d = dict(row)
    d["items"] = json.loads(d["items"]) if d["items"] else []
    d["fraud_flag"] = bool(d["fraud_flag"])
    d["inventory_flag"] = bool(d["inventory_flag"])
    return d
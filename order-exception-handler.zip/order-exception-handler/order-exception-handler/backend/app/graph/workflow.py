"""
The LangGraph workflow.

This is the file that actually defines the multi-agent graph: which nodes
exist, how state flows between them, and the conditional logic that decides
whether the Customer-comms agent runs at all.

GRAPH SHAPE:

                        ┌──────────────┐
                  ┌────▶│ fraud_check  │────┐
                  │     └──────────────┘    │
        START ────┤                         ├──▶ join_and_finalize ──┬─▶ customer_comms ──▶ END
                  │     ┌──────────────┐    │      (join node)       │
                  └────▶│  inventory   │────┘                        └────────────────────▶ END
                        └──────────────┘

fraud_check and inventory run in PARALLEL (true fan-out): LangGraph starts
both as soon as START fires. They share no dependency on each other, so
the executor runs them concurrently and waits for both before continuing.

join_and_finalize is a REAL NODE (not just a conditional-edge function)
that BOTH parallel branches point to unconditionally. Making it a real
node — rather than attaching routing logic directly to the two parallel
edges — gives us a guaranteed, unambiguous barrier: this node's body only
executes once, after both fraud_check and inventory_check have written
their state, because LangGraph will not run a node until every one of its
incoming edges has fired. Inside that single node we compute the final
status, then a conditional edge attached to THIS node decides whether to
continue to customer_comms or end the run. This keeps the fan-in and the
branch-on-flags decision each happening in exactly one place.
"""

from langgraph.graph import StateGraph, START, END
from app.models.state import OrderState
from app.agents.fraud_agent import run_fraud_check
from app.agents.inventory_agent import run_inventory_check
from app.agents.comms_agent import run_customer_comms


async def join_and_finalize(state: OrderState) -> dict:
    """
    This node is the FAN-IN / BARRIER point. LangGraph will not execute it
    until both fraud_check AND inventory_check have completed, because
    both are wired as direct predecessors (see add_edge calls below) — a
    node with multiple incoming edges waits for all of them.

    It does two jobs at once, deliberately combined here:
      1. Translate the raw agent flags into the order's final lifecycle
         status (one of: fulfilled / flagged / backordered).
      2. Return that update so route_after_join (the conditional edge
         attached to THIS node) can decide whether customer_comms needs
         to run at all.
    Keeping "compute final_status" and "decide whether comms is needed"
    fed by the same two flags in the same node means there is exactly one
    place that understands what a given combination of flags means for
    the order — a clean separation of concerns versus smearing this
    decision across the agents themselves.
    """
    fraud_flag = state.get("fraud_flag", False)
    inventory_flag = state.get("inventory_flag", False)

    if fraud_flag:
        # Fraud concerns take priority for human review even if inventory
        # was fine — we don't want to ship something that needs a fraud
        # check just because stock was available.
        status = "flagged"
    elif inventory_flag:
        status = "backordered"
    else:
        status = "fulfilled"

    return {"final_status": status}


def route_after_join(state: OrderState) -> str:
    """
    The CONDITIONAL EDGE function, attached only to join_and_finalize (one
    node, one set of outgoing routes — no ambiguity about how many times
    this fires). Returns a string key; LangGraph looks that key up in the
    `path_map` passed to add_conditional_edges to pick the next node. This
    is what lets the graph skip the comms agent entirely for the common
    case (no flags raised) instead of calling an LLM to draft an
    unnecessary "everything is fine" email.
    """
    needs_comms = state.get("fraud_flag", False) or state.get("inventory_flag", False)
    return "needs_comms" if needs_comms else "no_comms"


def build_order_graph():
    """
    Construct and compile the LangGraph StateGraph. Called once at app
    startup (see main.py) and the compiled graph is reused for every order
    — compiling is the relatively expensive part, running it isn't.
    """
    graph = StateGraph(OrderState)

    # Register every node. `graph.add_node(name, fn)` — `name` is the
    # string used everywhere else (edges, conditional path maps) to refer
    # to this step.
    graph.add_node("fraud_check", run_fraud_check)
    graph.add_node("inventory_check", run_inventory_check)
    graph.add_node("join_and_finalize", join_and_finalize)
    graph.add_node("customer_comms", run_customer_comms)

    # --- Fan-out: START branches to BOTH agents. ---
    # Adding two separate edges FROM the same source node is what creates
    # parallelism in LangGraph — both fraud_check and inventory_check
    # become runnable the instant START fires, with no dependency between
    # them, so the underlying executor runs them concurrently.
    graph.add_edge(START, "fraud_check")
    graph.add_edge(START, "inventory_check")

    # --- Fan-in: join_and_finalize has TWO incoming edges. LangGraph
    # only executes a node once every edge pointing to it has fired, so
    # this pair of edges is what creates the "wait for both agents"
    # barrier described in the docstring above. ---
    graph.add_edge("fraud_check", "join_and_finalize")
    graph.add_edge("inventory_check", "join_and_finalize")

    # --- Conditional branch out of the join node: skip comms entirely
    # when nothing was flagged. ---
    graph.add_conditional_edges(
        "join_and_finalize",
        route_after_join,
        {"needs_comms": "customer_comms", "no_comms": END},
    )
    graph.add_edge("customer_comms", END)

    return graph.compile()


# Compiled once, imported by api/routes.py and reused across every order —
# this is the object whose `.ainvoke(initial_state)` actually runs the
# pipeline.
order_graph = build_order_graph()

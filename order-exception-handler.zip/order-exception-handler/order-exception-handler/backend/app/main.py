"""
FastAPI application entrypoint.

Run with:  uvicorn app.main:app --reload --port 8000   (from the backend/ folder)
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.db.database import init_db
from app.api.routes import router as orders_router
from app.api.ws_manager import manager


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    FastAPI's modern way to run startup/shutdown code, replacing the older
    @app.on_event("startup") decorator (deprecated as of FastAPI 0.110+).
    Code before `yield` runs once when the server starts; code after would
    run on shutdown (we have nothing to clean up, so nothing follows here).
    """
    await init_db()  # creates the SQLite tables if they don't exist yet
    print(f"[startup] Database ready at {settings.DATABASE_PATH}")
    print(
        f"[startup] OpenAI key configured: {settings.has_openai_key} "
        f"(mock mode is used for agents when False)"
    )
    yield


app = FastAPI(title="Order Exception Handler", lifespan=lifespan)

# CORS: the React dev server runs on a different origin (localhost:5173)
# than the API (localhost:8000), so without this, the browser blocks every
# fetch/WebSocket call from the frontend with a CORS error. In production
# you'd set CORS_ORIGIN to your real deployed frontend URL.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.CORS_ORIGIN],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(orders_router)


@app.websocket("/ws/orders")
async def orders_websocket(websocket: WebSocket):
    """
    The dashboard opens ONE WebSocket connection here on page load. We
    don't expect any messages FROM the client on this socket — it's
    push-only, server-to-client — so the only thing we do with incoming
    messages is wait for a disconnect.
    """
    await manager.connect(websocket)
    try:
        while True:
            # We don't actually use anything the client sends, but we must
            # await receive_*() in a loop, or this coroutine returns
            # immediately and FastAPI tears down the connection right
            # after accepting it. This loop's real job is just "block
            # until the client disconnects."
            await websocket.receive_text()
    except WebSocketDisconnect:
        await manager.disconnect(websocket)


@app.get("/api/health")
async def health_check():
    """Simple endpoint to confirm the API is up — handy when wiring the
    frontend for the first time, before any real orders exist."""
    return {"status": "ok", "openai_configured": settings.has_openai_key}

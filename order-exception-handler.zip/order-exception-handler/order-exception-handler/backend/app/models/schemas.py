"""
Pydantic schemas = the API's contract.

These are NOT the same as the LangGraph state (see state.py). This is a
deliberate separation that's worth mentioning in an interview:
  - schemas.py describes what crosses the network (JSON in/out of FastAPI).
  - state.py describes what flows BETWEEN nodes inside one LangGraph run.
They overlap in content but serve different masters. If you collapse them
into one model, changing an internal agent field forces a frontend API
change too — which is exactly the kind of coupling you want to avoid.
"""

from pydantic import BaseModel, EmailStr, Field
from typing import Optional


class OrderItem(BaseModel):
    """One line item inside an order. Kept tiny on purpose — this project's
    focus is the agent orchestration, not a full product catalog."""

    sku: str
    name: str
    quantity: int = Field(gt=0)  # gt=0: Pydantic rejects quantity <= 0 automatically
    unit_price: float = Field(gt=0)


class OrderWebhookPayload(BaseModel):
    """
    Shape of the incoming webhook (what an e-commerce platform like Shopify
    would POST to us). EmailStr gives free email-format validation — a
    malformed email gets rejected with a 422 before it ever reaches our code.
    """

    customer_name: str
    customer_email: EmailStr
    items: list[OrderItem]
    shipping_country: str = Field(min_length=2, max_length=2)  # ISO country code

    @property
    def total_amount(self) -> float:
        """Computed, not stored on the payload itself — total is derived
        from line items, so there is no way for it to disagree with them."""
        return sum(item.quantity * item.unit_price for item in self.items)


class OrderOut(BaseModel):
    """
    What we send BACK to the frontend for a single order. Every field here
    is intentionally optional-safe: a brand new order won't have a
    fraud_reason yet, so that field is Optional rather than forcing a
    placeholder string.
    """

    id: str
    customer_name: str
    customer_email: str
    items: list[OrderItem]
    total_amount: float
    shipping_country: str
    status: str
    fraud_flag: bool
    fraud_reason: Optional[str] = None
    inventory_flag: bool
    inventory_reason: Optional[str] = None
    backorder_eta: Optional[str] = None
    customer_email_draft: Optional[str] = None
    created_at: str
    updated_at: str


class AgentEventOut(BaseModel):
    """One row of the audit trail, as sent to the frontend's AgentTrace panel."""

    id: int
    order_id: str
    agent_name: str
    event_type: str
    detail: Optional[str] = None
    created_at: str


class WSMessage(BaseModel):
    """
    Envelope for every WebSocket push. `type` tells the frontend how to
    handle `payload` without it having to guess from shape alone — this is
    the same pattern Redux/most event-bus systems use, and it's what lets
    us add new event types later (e.g. "stats_update") without breaking
    existing frontend code that only handles the types it knows.
    """

    type: str  # 'order_created' | 'order_updated' | 'agent_event'
    payload: dict

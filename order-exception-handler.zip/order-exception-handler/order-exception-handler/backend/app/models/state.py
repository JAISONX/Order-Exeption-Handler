"""
The LangGraph state object.

In LangGraph, every node in the graph receives the CURRENT state and
returns a PARTIAL dict of updates. LangGraph merges that partial dict into
the state before passing it to the next node. This file defines the shape
of that shared state for our order-processing graph.

We use a TypedDict (not a Pydantic model) because that's what LangGraph's
StateGraph expects natively — it inspects the TypedDict's annotations to
know which keys exist and how to merge updates for each key.
"""

from typing import TypedDict, Optional, Annotated
import operator


def keep_last(left, right):
    """
    Reducer function for fields where, if two nodes both return a value for
    the same key, we want to just take the newer one (overwrite) rather
    than combine them. This is the default behavior in LangGraph if you
    don't specify Annotated — but we make it explicit here for clarity in
    the few fields that go through a parallel fan-out (fraud + inventory
    run at the same time, see workflow.py), since those are exactly the
    fields where "how do two simultaneous writes merge?" matters most.
    """
    return right if right is not None else left


class OrderState(TypedDict):
    """
    Shared state that flows through the whole graph for ONE order.

    Why a flat dict instead of nested objects: LangGraph's update-merging
    works key-by-key at the top level. Nesting would mean a node updating
    one nested field has to carefully reconstruct the whole nested object
    or risk clobbering sibling fields written by a parallel node. Flat
    state sidesteps that entirely — each agent only touches its own keys.
    """

    # ---- input, set once when the graph starts, never changed after ----
    order_id: str
    customer_name: str
    customer_email: str
    items: list[dict]
    total_amount: float
    shipping_country: str

    # ---- written by the Fraud-check agent ----
    fraud_flag: Annotated[Optional[bool], keep_last]
    fraud_reason: Annotated[Optional[str], keep_last]

    # ---- written by the Inventory agent ----
    inventory_flag: Annotated[Optional[bool], keep_last]
    inventory_reason: Annotated[Optional[str], keep_last]
    backorder_eta: Annotated[Optional[str], keep_last]

    # ---- written by the Customer-comms agent (only runs if flagged) ----
    customer_email_draft: Annotated[Optional[str], keep_last]

    # ---- the order's lifecycle status, written by the router/end nodes ----
    final_status: Annotated[Optional[str], keep_last]

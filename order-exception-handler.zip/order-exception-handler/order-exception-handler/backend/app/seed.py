"""
Demo data seeder.

Run with:  python -m app.seed   (from the backend/ folder, with the API
already running in another terminal)

This sends real HTTP requests to the running webhook endpoint rather than
writing to the database directly — that way it exercises the EXACT same
code path a real e-commerce platform's webhook would, including the full
LangGraph pipeline running for each order. This is what makes the
dashboard come alive with a realistic mix of fulfilled/flagged/backordered
orders for a demo, instead of you manually submitting orders one at a time.
"""

import asyncio
import httpx

API_URL = "http://localhost:8000/api/orders/webhook"

# A deliberately varied mix: some clean orders, one that should trip
# fraud (high value), one that should trip inventory (huge quantity, which
# our seeded random stock simulation will very likely not cover), and one
# that's borderline normal. This variety is what makes the demo dashboard
# show all five order states instead of just "fulfilled" five times.
DEMO_ORDERS = [
    {
        "customer_name": "Asha Menon",
        "customer_email": "asha.menon@example.com",
        "shipping_country": "IN",
        "items": [
            {"sku": "SKU-1001", "name": "Wireless Mouse", "quantity": 1, "unit_price": 25.0},
            {"sku": "SKU-1002", "name": "USB-C Hub", "quantity": 1, "unit_price": 40.0},
        ],
    },
    {
        "customer_name": "Daniel Cho",
        "customer_email": "daniel.cho@example.com",
        "shipping_country": "US",
        "items": [
            {"sku": "SKU-2050", "name": "4K Monitor", "quantity": 6, "unit_price": 320.0},
        ],
    },
    {
        "customer_name": "Fatima Noor",
        "customer_email": "fatima.noor@example.com",
        "shipping_country": "AE",
        "items": [
            {"sku": "SKU-3300", "name": "Office Chair", "quantity": 25, "unit_price": 150.0},
        ],
    },
    {
        "customer_name": "Liam O'Brien",
        "customer_email": "liam.obrien@example.com",
        "shipping_country": "IE",
        "items": [
            {"sku": "SKU-1003", "name": "Mechanical Keyboard", "quantity": 2, "unit_price": 89.0},
            {"sku": "SKU-1004", "name": "Desk Mat", "quantity": 1, "unit_price": 18.0},
        ],
    },
    {
        "customer_name": "Mei Lin",
        "customer_email": "mei.lin@example.com",
        "shipping_country": "SG",
        "items": [
            {"sku": "SKU-4400", "name": "Studio Headphones", "quantity": 3, "unit_price": 199.0},
        ],
    },
]


async def seed():
    async with httpx.AsyncClient() as client:
        for order in DEMO_ORDERS:
            try:
                resp = await client.post(API_URL, json=order, timeout=10)
                resp.raise_for_status()
                created = resp.json()
                print(f"Created {created['id']} for {order['customer_name']}")
            except httpx.HTTPStatusError as exc:
                print(f"FAILED for {order['customer_name']}: {exc.response.text}")
            # Small delay between orders so the dashboard's "live arrival"
            # animation is visible per-order instead of all five appearing
            # in the same instant.
            await asyncio.sleep(1.5)


if __name__ == "__main__":
    asyncio.run(seed())

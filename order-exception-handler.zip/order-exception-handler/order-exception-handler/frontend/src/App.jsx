import React, { useState } from "react";
import { useOrdersSocket } from "./hooks/useOrdersSocket.js";
import StatsBar from "./components/StatsBar.jsx";
import NewOrderForm from "./components/NewOrderForm.jsx";
import PipelineBoard from "./components/PipelineBoard.jsx";
import OrderDetailDrawer from "./components/OrderDetailDrawer.jsx";

/**
 * Root component. Deliberately thin: all the real data logic lives in
 * useOrdersSocket, all the real rendering logic lives in the child
 * components. App's only job is to own the "which order is the drawer
 * showing" UI state and wire everything else together — that's the kind
 * of separation that makes a codebase easy for someone else (or an
 * interviewer skimming your GitHub) to navigate.
 */
export default function App() {
  const { orders, connectionStatus, liveAgentStatus } = useOrdersSocket();
  const [selectedOrder, setSelectedOrder] = useState(null);

  // When the WebSocket pushes an update for the order that's currently
  // open in the drawer, we want the drawer to reflect that update live
  // too (e.g. fraud_flag flipping from null to true while open) rather
  // than showing a stale snapshot from the moment it was clicked.
  const liveSelectedOrder = selectedOrder
    ? orders.find((o) => o.id === selectedOrder.id) ?? selectedOrder
    : null;

  return (
    <div style={styles.app}>
      <StatsBar orders={orders} connectionStatus={connectionStatus} />
      <div style={styles.body}>
        <aside style={styles.sidebar}>
          <div style={styles.sidebarLabel}>Simulate a webhook</div>
          <NewOrderForm />
        </aside>
        <PipelineBoard
          orders={orders}
          liveAgentStatus={liveAgentStatus}
          onSelectOrder={setSelectedOrder}
        />
      </div>
      <OrderDetailDrawer
        order={liveSelectedOrder}
        onClose={() => setSelectedOrder(null)}
        liveAgentStatus={liveAgentStatus}
      />
    </div>
  );
}

const styles = {
  app: {
    display: "flex",
    flexDirection: "column",
    minHeight: "100vh",
  },
  body: {
    display: "flex",
    flex: 1,
    minHeight: 0,
  },
  sidebar: {
    width: "260px",
    flexShrink: 0,
    padding: "20px",
    borderRight: "1px solid var(--border)",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  sidebarLabel: {
    fontFamily: "var(--font-mono)",
    fontSize: "11px",
    textTransform: "uppercase",
    letterSpacing: "0.06em",
    color: "var(--text-tertiary)",
  },
};

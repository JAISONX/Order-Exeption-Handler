import React, { useEffect, useState } from "react";
import { fetchOrderEvents } from "../lib/api.js";

// Same icon-by-agent-name convention as OrderCard.jsx, repeated here
// rather than imported from a shared constants file — for a project this
// size, the very small duplication is cheaper than the indirection of a
// shared constants module that only two files would ever import.
const AGENT_LABELS = {
  fraud: "Fraud check",
  inventory: "Inventory",
  comms: "Customer comms",
};

const EVENT_COLOR = {
  started: "var(--status-checked)",
  completed: "var(--status-fulfilled)",
  error: "var(--status-flagged)",
};

/**
 * Renders the append-only agent_events log for one order as a vertical
 * timeline. This is the "show your reasoning" panel — for a recruiter,
 * this is the part of the UI that proves the system is actually running
 * multiple distinct agents with real control flow, not one prompt
 * pretending to be three agents.
 *
 * This component owns its OWN data fetching (rather than receiving
 * `events` as a prop from a parent) because the drawer that renders it
 * only knows an order's `id` — it doesn't track the agent trace itself.
 * Re-fetches whenever `orderId` changes, which happens every time the
 * user clicks a different order card.
 *
 * `liveEvent` (optional) is the latest agent_event the WebSocket has
 * delivered for this order — passed down from App via the drawer. If the
 * user has the drawer open WHILE an order is being processed, we want the
 * trace to grow live rather than only showing whatever existed at the
 * moment the drawer was opened. We append it locally instead of
 * re-fetching the whole list on every event, which would hammer the API
 * for no reason.
 */
export default function AgentTrace({ orderId, liveEvent }) {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orderId) return;
    let isMounted = true;
    setLoading(true);

    fetchOrderEvents(orderId)
      .then((data) => {
        if (isMounted) setEvents(data);
      })
      .catch((err) => console.error("Failed to load agent trace:", err))
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [orderId]);

  // Append a freshly-arrived live event for THIS order, but only once
  // we've finished the initial fetch (otherwise we might append something
  // that the fetch is about to bring back anyway, creating a duplicate).
  useEffect(() => {
    if (!liveEvent || loading) return;
    if (liveEvent.order_id !== orderId) return;
    setEvents((prev) => [
      ...prev,
      {
        // The WebSocket payload has no DB row `id` (it's pushed before
        // the row is necessarily committed/read back), so we synthesize
        // a temporary key from the timestamp of arrival. This is fine
        // since it's only used as a React list key, never displayed.
        id: `live-${Date.now()}`,
        order_id: liveEvent.order_id,
        agent_name: liveEvent.agent_name,
        event_type: liveEvent.event_type,
        detail: liveEvent.detail,
        created_at: new Date().toISOString(),
      },
    ]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [liveEvent, loading, orderId]);

  if (loading) {
    return <div style={styles.empty}>Loading trace…</div>;
  }

  if (events.length === 0) {
    return <div style={styles.empty}>No agent activity yet.</div>;
  }

  return (
    <div style={styles.timeline}>
      {events.map((event) => (
        <div key={event.id} style={styles.eventRow}>
          <span
            style={{
              ...styles.eventDot,
              background: EVENT_COLOR[event.event_type] ?? "var(--border)",
            }}
          />
          <div style={styles.eventBody}>
            <div style={styles.eventHeadline}>
              <span style={styles.agentName}>
                {AGENT_LABELS[event.agent_name] ?? event.agent_name}
              </span>
              <span style={styles.eventType}>{event.event_type}</span>
            </div>
            {event.detail && <div style={styles.eventDetail}>{event.detail}</div>}
            <div style={styles.eventTime}>
              {new Date(event.created_at).toLocaleTimeString()}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

const styles = {
  empty: {
    fontSize: "13px",
    color: "var(--text-tertiary)",
    fontStyle: "italic",
  },
  timeline: {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
  },
  eventRow: {
    display: "flex",
    gap: "10px",
  },
  eventDot: {
    width: "8px",
    height: "8px",
    borderRadius: "50%",
    marginTop: "5px",
    flexShrink: 0,
  },
  eventBody: {
    display: "flex",
    flexDirection: "column",
    gap: "2px",
  },
  eventHeadline: {
    display: "flex",
    gap: "8px",
    alignItems: "baseline",
  },
  agentName: {
    fontSize: "13px",
    fontWeight: 600,
  },
  eventType: {
    fontFamily: "var(--font-mono)",
    fontSize: "11px",
    color: "var(--text-secondary)",
    textTransform: "uppercase",
  },
  eventDetail: {
    fontSize: "12px",
    color: "var(--text-secondary)",
  },
  eventTime: {
    fontFamily: "var(--font-mono)",
    fontSize: "10px",
    color: "var(--text-tertiary)",
  },
};

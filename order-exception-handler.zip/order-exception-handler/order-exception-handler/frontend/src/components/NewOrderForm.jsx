import React, { useState } from "react";
import { submitOrderWebhook } from "../lib/api";

// Three preset scenarios instead of a fully free-form item builder. The
// point of this form is letting a recruiter trigger the pipeline live
// during a demo without typing out a whole order by hand — presets that
// are pre-tuned to land in each of the three outcome buckets (clean,
// fraud-flagged, backordered) tell a much clearer story in 30 seconds
// than a generic "add item" form would.
const PRESETS = {
  normal: {
    label: "Normal order",
    items: [{ sku: "SKU-9001", name: "Notebook", quantity: 1, unit_price: 12 }],
  },
  fraud: {
    label: "High-value order (likely fraud flag)",
    items: [{ sku: "SKU-9002", name: "Gaming Laptop", quantity: 1, unit_price: 2200 }],
  },
  backorder: {
    label: "Bulk order (likely backorder)",
    items: [{ sku: "SKU-9003", name: "Office Chair", quantity: 30, unit_price: 140 }],
  },
};

export default function NewOrderForm({ onSubmitted }) {
  const [customerName, setCustomerName] = useState("Jordan Lee");
  const [customerEmail, setCustomerEmail] = useState("jordan.lee@example.com");
  const [country, setCountry] = useState("US");
  const [preset, setPreset] = useState("normal");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const created = await submitOrderWebhook({
        customer_name: customerName,
        customer_email: customerEmail,
        shipping_country: country,
        items: PRESETS[preset].items,
      });
      onSubmitted?.(created);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} style={styles.form}>
      <div style={styles.fieldGroup}>
        <label style={styles.label} htmlFor="customerName">Customer name</label>
        <input
          id="customerName"
          style={styles.input}
          value={customerName}
          onChange={(e) => setCustomerName(e.target.value)}
          required
        />
      </div>

      <div style={styles.fieldGroup}>
        <label style={styles.label} htmlFor="customerEmail">Email</label>
        <input
          id="customerEmail"
          type="email"
          style={styles.input}
          value={customerEmail}
          onChange={(e) => setCustomerEmail(e.target.value)}
          required
        />
      </div>

      <div style={styles.fieldGroup}>
        <label style={styles.label} htmlFor="country">Ship to (ISO country)</label>
        <input
          id="country"
          style={styles.input}
          value={country}
          onChange={(e) => setCountry(e.target.value.toUpperCase())}
          maxLength={2}
          required
        />
      </div>

      <div style={styles.fieldGroup}>
        <label style={styles.label} htmlFor="preset">Order scenario</label>
        <select
          id="preset"
          style={styles.input}
          value={preset}
          onChange={(e) => setPreset(e.target.value)}
        >
          {Object.entries(PRESETS).map(([key, p]) => (
            <option key={key} value={key}>{p.label}</option>
          ))}
        </select>
      </div>

      <button type="submit" style={styles.submitButton} disabled={submitting}>
        {submitting ? "Sending…" : "Send order webhook"}
      </button>

      {error && <div style={styles.error}>{error}</div>}
    </form>
  );
}

const styles = {
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
    padding: "16px",
    background: "var(--panel-raised)",
    border: "1px solid var(--border-soft)",
    borderRadius: "var(--radius-md)",
    minWidth: "220px",
  },
  fieldGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "4px",
  },
  label: {
    fontSize: "11px",
    color: "var(--text-secondary)",
    textTransform: "uppercase",
    letterSpacing: "0.04em",
  },
  input: {
    background: "var(--bg)",
    border: "1px solid var(--border)",
    borderRadius: "var(--radius-sm)",
    color: "var(--text-primary)",
    padding: "8px 10px",
    fontSize: "13px",
    fontFamily: "inherit",
  },
  submitButton: {
    background: "var(--accent)",
    color: "#0e1116",
    border: "none",
    borderRadius: "var(--radius-sm)",
    padding: "10px 14px",
    fontWeight: 600,
    fontSize: "13px",
    cursor: "pointer",
    marginTop: "4px",
  },
  error: {
    color: "var(--status-flagged)",
    fontSize: "12px",
  },
};

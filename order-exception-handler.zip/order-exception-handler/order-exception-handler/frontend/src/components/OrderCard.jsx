import React from "react";

// Maps an order's status to the color it should render with everywhere
// (the card's left border, the small status chip, etc). Centralizing this
// mapping here means if we ever add a sixth status, there's exactly one
// place to update — no risk of two components disagreeing on what color
// "backordered" should be.
const STATUS_COLOR = {
  received: "var(--status-received)",
  checked: "var(--status-checked)",
  fulfilled: "var(--status-fulfilled)",
  backordered: "var(--status-backordered)",
  flagged: "var(--status-flagged)",
};

const AGENT_LABELS = {
  fraud: "Fraud check",
  inventory: "Inventory",
  comms: "Customer comms",
};

/**
 * `liveAgent` is the most recent agent_event the WebSocket has delivered
 * for THIS order (or undefined if none yet) — see useOrdersSocket.js.
 * When its event_type is "started", we render a pulsing dot next to that
 * agent's name. This is the project's signature visual: it makes the
 * normally-invisible moment of "an LLM call is in flight" actually
 * visible on screen, which is exactly the thing that's hardest to
 * communicate about agentic systems in a static screenshot.
 */
export default function OrderCard({ order, liveAgent, onSelect }) {
  const isActiveAgent = (agentName) =>
    liveAgent?.agent_name === agentName && liveAgent.event_type === "started";

  return (
    <button
      onClick={() => onSelect(order)}
      style={{
        ...styles.card,
        borderLeft: `3px solid ${STATUS_COLOR[order.status] ?? "var(--border)"}`,
      }}
    >
      <div style={styles.topRow}>
        <span style={styles.orderId}>{order.id}</span>
        <span
          style={{
            ...styles.statusChip,
            color: STATUS_COLOR[order.status],
            borderColor: STATUS_COLOR[order.status],
          }}
        >
          {order.status}
        </span>
      </div>

      <div style={styles.customerName}>{order.customer_name}</div>
      <div style={styles.amount}>
        ${order.total_amount.toFixed(2)} · {order.shipping_country}
      </div>

      {/* Agent activity row — three dots, one per agent, that light up
          and pulse while that agent is actively processing this order. */}
      <div style={styles.agentRow}>
        {Object.entries(AGENT_LABELS).map(([key, label]) => (
          <span key={key} style={styles.agentBadge}>
            <span
              style={{
                ...styles.agentDot,
                background: isActiveAgent(key)
                  ? "var(--accent)"
                  : "var(--border)",
                animation: isActiveAgent(key) ? "pulse 1.1s ease-in-out infinite" : "none",
              }}
            />
            {label}
          </span>
        ))}
      </div>

      {(order.fraud_flag || order.inventory_flag) && (
        <div style={styles.exceptionNote}>
          {order.fraud_flag ? order.fraud_reason : order.inventory_reason}
        </div>
      )}

      {/* Keyframes need to live somewhere global since inline styles can't
          define @keyframes — injected once per card is wasteful but
          harmless at this scale; see App.jsx for the single global
          stylesheet alternative used for the drawer transition instead. */}
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.3); }
        }
      `}</style>
    </button>
  );
}

const styles = {
  card: {
    display: "flex",
    flexDirection: "column",
    gap: "8px",
    width: "100%",
    textAlign: "left",
    background: "var(--panel-raised)",
    border: "1px solid var(--border-soft)",
    borderRadius: "var(--radius-md)",
    padding: "14px 16px",
    cursor: "pointer",
    color: "inherit",
    fontFamily: "inherit",
  },
  topRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  orderId: {
    fontFamily: "var(--font-mono)",
    fontSize: "12px",
    color: "var(--text-secondary)",
  },
  statusChip: {
    fontFamily: "var(--font-mono)",
    fontSize: "10px",
    textTransform: "uppercase",
    letterSpacing: "0.04em",
    border: "1px solid",
    borderRadius: "999px",
    padding: "2px 8px",
  },
  customerName: {
    fontFamily: "var(--font-display)",
    fontSize: "15px",
    fontWeight: 600,
  },
  amount: {
    fontFamily: "var(--font-mono)",
    fontSize: "12px",
    color: "var(--text-secondary)",
  },
  agentRow: {
    display: "flex",
    gap: "12px",
    marginTop: "4px",
    flexWrap: "wrap",
  },
  agentBadge: {
    display: "flex",
    alignItems: "center",
    gap: "5px",
    fontSize: "11px",
    color: "var(--text-tertiary)",
  },
  agentDot: {
    width: "6px",
    height: "6px",
    borderRadius: "50%",
    display: "inline-block",
  },
  exceptionNote: {
    fontSize: "12px",
    color: "var(--status-flagged)",
    background: "rgba(240, 71, 61, 0.1)",
    borderRadius: "var(--radius-sm)",
    padding: "6px 8px",
    marginTop: "2px",
  },
};

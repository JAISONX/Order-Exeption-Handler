import React from "react";
import AgentTrace from "./AgentTrace.jsx";

/**
 * Controlled by `order` being null vs. an object — there's no separate
 * "isOpen" boolean. This is a small but deliberate choice: it makes it
 * IMPOSSIBLE for the drawer to be "open" while having no order to show,
 * a state that would otherwise need its own defensive null-check deep in
 * the render tree.
 */
export default function OrderDetailDrawer({ order, onClose, liveAgentStatus }) {
  const isOpen = order !== null;

  return (
    <>
      {/* Backdrop: click outside the panel to close. Rendered even when
          closed (opacity/pointer-events toggle) rather than conditionally
          mounted, so the closing transition has something to animate. */}
      <div
        onClick={onClose}
        style={{
          ...styles.backdrop,
          opacity: isOpen ? 1 : 0,
          pointerEvents: isOpen ? "auto" : "none",
        }}
      />

      <aside
        style={{
          ...styles.drawer,
          transform: isOpen ? "translateX(0)" : "translateX(100%)",
        }}
        aria-hidden={!isOpen}
      >
        {order && (
          <>
            <div style={styles.header}>
              <div>
                <div style={styles.orderId}>{order.id}</div>
                <h2 style={styles.customerName}>{order.customer_name}</h2>
              </div>
              <button onClick={onClose} style={styles.closeButton} aria-label="Close detail panel">
                ✕
              </button>
            </div>

            <Section title="Order">
              <Row label="Email" value={order.customer_email} />
              <Row label="Total" value={`$${order.total_amount.toFixed(2)}`} />
              <Row label="Ships to" value={order.shipping_country} />
              <Row label="Status" value={order.status} />
              <div style={styles.itemsList}>
                {order.items.map((item) => (
                  <div key={item.sku} style={styles.itemRow}>
                    <span>{item.name}</span>
                    <span style={styles.itemMeta}>
                      {item.quantity} × ${item.unit_price.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </Section>

            {(order.fraud_flag || order.inventory_flag) && (
              <Section title="Exceptions">
                {order.fraud_flag && (
                  <ExceptionBlock title="Fraud check" reason={order.fraud_reason} />
                )}
                {order.inventory_flag && (
                  <ExceptionBlock
                    title="Inventory"
                    reason={order.inventory_reason}
                    extra={order.backorder_eta ? `ETA: ${order.backorder_eta}` : null}
                  />
                )}
              </Section>
            )}

            {order.customer_email_draft && (
              <Section title="Drafted customer email">
                <pre style={styles.emailDraft}>{order.customer_email_draft}</pre>
              </Section>
            )}

            <Section title="Agent trace">
              <AgentTrace orderId={order.id} liveEvent={liveAgentStatus?.[order.id]} />
            </Section>
          </>
        )}
      </aside>
    </>
  );
}

function Section({ title, children }) {
  return (
    <div style={styles.section}>
      <div style={styles.sectionTitle}>{title}</div>
      {children}
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div style={styles.row}>
      <span style={styles.rowLabel}>{label}</span>
      <span style={styles.rowValue}>{value}</span>
    </div>
  );
}

function ExceptionBlock({ title, reason, extra }) {
  return (
    <div style={styles.exceptionBlock}>
      <div style={styles.exceptionTitle}>{title}</div>
      <div style={styles.exceptionReason}>{reason}</div>
      {extra && <div style={styles.exceptionExtra}>{extra}</div>}
    </div>
  );
}

const styles = {
  backdrop: {
    position: "fixed",
    inset: 0,
    background: "rgba(0,0,0,0.5)",
    transition: "opacity 200ms ease",
    zIndex: 20,
  },
  drawer: {
    position: "fixed",
    top: 0,
    right: 0,
    height: "100vh",
    width: "min(420px, 92vw)",
    background: "var(--panel)",
    borderLeft: "1px solid var(--border)",
    overflowY: "auto",
    transition: "transform 240ms cubic-bezier(0.4, 0, 0.2, 1)",
    zIndex: 21,
    padding: "24px",
    display: "flex",
    flexDirection: "column",
    gap: "20px",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  orderId: {
    fontFamily: "var(--font-mono)",
    fontSize: "12px",
    color: "var(--text-secondary)",
  },
  customerName: {
    fontFamily: "var(--font-display)",
    fontSize: "20px",
    margin: "4px 0 0",
  },
  closeButton: {
    background: "transparent",
    border: "1px solid var(--border)",
    color: "var(--text-secondary)",
    borderRadius: "var(--radius-sm)",
    width: "30px",
    height: "30px",
    cursor: "pointer",
  },
  section: {
    borderTop: "1px solid var(--border-soft)",
    paddingTop: "16px",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  sectionTitle: {
    fontFamily: "var(--font-mono)",
    fontSize: "11px",
    textTransform: "uppercase",
    letterSpacing: "0.06em",
    color: "var(--text-tertiary)",
  },
  row: {
    display: "flex",
    justifyContent: "space-between",
    fontSize: "13px",
  },
  rowLabel: {
    color: "var(--text-secondary)",
  },
  rowValue: {
    fontFamily: "var(--font-mono)",
  },
  itemsList: {
    display: "flex",
    flexDirection: "column",
    gap: "4px",
    marginTop: "6px",
  },
  itemRow: {
    display: "flex",
    justifyContent: "space-between",
    fontSize: "13px",
  },
  itemMeta: {
    fontFamily: "var(--font-mono)",
    color: "var(--text-secondary)",
  },
  exceptionBlock: {
    background: "rgba(240, 71, 61, 0.08)",
    border: "1px solid rgba(240, 71, 61, 0.25)",
    borderRadius: "var(--radius-sm)",
    padding: "10px 12px",
  },
  exceptionTitle: {
    fontSize: "12px",
    fontWeight: 600,
    color: "var(--status-flagged)",
  },
  exceptionReason: {
    fontSize: "13px",
    marginTop: "2px",
  },
  exceptionExtra: {
    fontFamily: "var(--font-mono)",
    fontSize: "12px",
    color: "var(--text-secondary)",
    marginTop: "4px",
  },
  emailDraft: {
    fontFamily: "var(--font-mono)",
    fontSize: "12px",
    whiteSpace: "pre-wrap",
    background: "var(--panel-raised)",
    border: "1px solid var(--border-soft)",
    borderRadius: "var(--radius-sm)",
    padding: "12px",
    margin: 0,
    lineHeight: 1.5,
  },
};

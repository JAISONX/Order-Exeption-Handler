import React from "react";
import OrderCard from "./OrderCard";

// Column order matters here: it mirrors the actual lifecycle described in
// the spec (received -> checked -> fulfilled/backordered, with flagged
// pulled out as its own lane since that's the one that needs a human).
// Putting "Flagged" last (rather than where "checked" logically sits)
// is a deliberate UX choice: exceptions are the rarest, most important
// column, and reading left-to-right as "the happy path, then the
// exception lane" matches how an ops person actually scans a board.
const COLUMNS = [
  { status: "received", label: "Received" },
  { status: "checked", label: "Checking" },
  { status: "fulfilled", label: "Fulfilled" },
  { status: "backordered", label: "Backordered" },
  { status: "flagged", label: "Flagged — needs review" },
];

/**
 * Groups the flat `orders` array into columns by status and renders each
 * as its own scrollable lane. Grouping happens here (not in the
 * useOrdersSocket hook) because "how orders are grouped for display" is
 * a presentation concern, not a data-fetching concern — the hook's job
 * ends at handing back a flat, up-to-date list.
 */
export default function PipelineBoard({ orders, liveAgentStatus, onSelectOrder }) {
  const grouped = COLUMNS.reduce((acc, col) => {
    acc[col.status] = orders.filter((o) => o.status === col.status);
    return acc;
  }, {});

  return (
    <div style={styles.board}>
      {COLUMNS.map((col) => (
        <div key={col.status} style={styles.column}>
          <div style={styles.columnHeader}>
            <span>{col.label}</span>
            <span style={styles.columnCount}>{grouped[col.status].length}</span>
          </div>

          <div style={styles.columnBody}>
            {grouped[col.status].length === 0 && (
              <div style={styles.emptyLane}>No orders</div>
            )}
            {grouped[col.status].map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                liveAgent={liveAgentStatus[order.id]}
                onSelect={onSelectOrder}
              />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

const styles = {
  board: {
    display: "flex",
    gap: "16px",
    padding: "20px 28px",
    overflowX: "auto",
    flex: 1,
    alignItems: "flex-start",
  },
  column: {
    display: "flex",
    flexDirection: "column",
    minWidth: "260px",
    width: "260px",
    flexShrink: 0,
    background: "var(--panel)",
    border: "1px solid var(--border-soft)",
    borderRadius: "var(--radius-lg)",
    maxHeight: "calc(100vh - 160px)",
  },
  columnHeader: {
    display: "flex",
    justifyContent: "space-between",
    padding: "12px 14px",
    borderBottom: "1px solid var(--border-soft)",
    fontSize: "12px",
    fontWeight: 600,
    color: "var(--text-secondary)",
  },
  columnCount: {
    fontFamily: "var(--font-mono)",
    color: "var(--text-tertiary)",
  },
  columnBody: {
    display: "flex",
    flexDirection: "column",
    gap: "10px",
    padding: "12px",
    overflowY: "auto",
  },
  emptyLane: {
    fontSize: "12px",
    color: "var(--text-tertiary)",
    fontStyle: "italic",
    padding: "8px 0",
    textAlign: "center",
  },
};

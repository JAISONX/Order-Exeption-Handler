import React from "react";

/**
 * Derives counts from the live `orders` array rather than the backend
 * sending a separate "stats" payload. Keeping this derived (computed in
 * render) instead of stored as its own piece of state means it can never
 * drift out of sync with the order list — there is only one source of
 * truth (the orders array), and this is just a view over it.
 */
function computeStats(orders) {
  const stats = {
    total: orders.length,
    received: 0,
    checked: 0,
    fulfilled: 0,
    flagged: 0,
    backordered: 0,
  };
  for (const order of orders) {
    if (stats[order.status] !== undefined) stats[order.status] += 1;
  }
  return stats;
}

const STAT_DEFS = [
  { key: "received", label: "Received", colorVar: "--status-received" },
  { key: "checked", label: "Checking", colorVar: "--status-checked" },
  { key: "fulfilled", label: "Fulfilled", colorVar: "--status-fulfilled" },
  { key: "backordered", label: "Backordered", colorVar: "--status-backordered" },
  { key: "flagged", label: "Flagged", colorVar: "--status-flagged" },
];

export default function StatsBar({ orders, connectionStatus }) {
  const stats = computeStats(orders);

  return (
    <div style={styles.bar}>
      <div style={styles.left}>
        <h1 style={styles.title}>Order Exception Handler</h1>
        <span style={styles.subtitle}>Live ops console</span>
      </div>

      <div style={styles.statsGroup}>
        {STAT_DEFS.map((def) => (
          <div key={def.key} style={styles.statItem}>
            <span
              style={{ ...styles.statDot, background: `var(${def.colorVar})` }}
            />
            <span style={styles.statCount}>{stats[def.key]}</span>
            <span style={styles.statLabel}>{def.label}</span>
          </div>
        ))}
      </div>

      <div style={styles.connectionWrap}>
        <span
          style={{
            ...styles.connectionDot,
            background:
              connectionStatus === "open"
                ? "var(--status-fulfilled)"
                : "var(--status-flagged)",
          }}
        />
        <span style={styles.connectionLabel}>
          {connectionStatus === "open" ? "Live" : "Reconnecting…"}
        </span>
      </div>
    </div>
  );
}

const styles = {
  bar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "16px 28px",
    borderBottom: "1px solid var(--border)",
    background: "var(--panel)",
    gap: "24px",
    flexWrap: "wrap",
  },
  left: {
    display: "flex",
    flexDirection: "column",
    gap: "2px",
    minWidth: "220px",
  },
  title: {
    fontFamily: "var(--font-display)",
    fontSize: "18px",
    fontWeight: 700,
    margin: 0,
    letterSpacing: "-0.01em",
  },
  subtitle: {
    fontFamily: "var(--font-mono)",
    fontSize: "12px",
    color: "var(--text-secondary)",
  },
  statsGroup: {
    display: "flex",
    gap: "22px",
    flexWrap: "wrap",
  },
  statItem: {
    display: "flex",
    alignItems: "baseline",
    gap: "8px",
  },
  statDot: {
    width: "8px",
    height: "8px",
    borderRadius: "50%",
    display: "inline-block",
    marginRight: "-2px",
  },
  statCount: {
    fontFamily: "var(--font-mono)",
    fontSize: "16px",
    fontWeight: 500,
  },
  statLabel: {
    fontSize: "12px",
    color: "var(--text-secondary)",
  },
  connectionWrap: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
  },
  connectionDot: {
    width: "7px",
    height: "7px",
    borderRadius: "50%",
    display: "inline-block",
  },
  connectionLabel: {
    fontFamily: "var(--font-mono)",
    fontSize: "12px",
    color: "var(--text-secondary)",
  },
};

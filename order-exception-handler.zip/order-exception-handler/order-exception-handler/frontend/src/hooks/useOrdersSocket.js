import { useEffect, useRef, useState, useCallback } from "react";
import { fetchOrders } from "../lib/api";

const WS_URL = "ws://localhost:8000/ws/orders";
// If the socket drops (server restarted, network hiccup), retry after a
// fixed delay rather than hammering the server in a tight reconnect loop.
const RECONNECT_DELAY_MS = 2000;

/**
 * Owns the entire "live orders" data model for the dashboard:
 *   1. On mount, does a normal REST fetch to get whatever orders already
 *      exist (so refreshing the page doesn't lose history).
 *   2. Opens a WebSocket and keeps the in-memory order list in sync with
 *      every order_created / order_updated event the server pushes.
 *   3. Tracks the most recent agent_event per order so OrderCard can show
 *      a live "fraud agent thinking..." style indicator without a
      separate fetch per card.
 *
 * Returning all of this from one hook (rather than splitting socket
 * logic and REST logic across two hooks) is deliberate: the REST fetch
 * and the WebSocket stream write into the SAME `orders` state, and having
 * one hook own that state avoids two independent pieces of code racing to
 * update it.
 */
export function useOrdersSocket() {
  const [orders, setOrders] = useState([]);
  const [connectionStatus, setConnectionStatus] = useState("connecting"); // 'connecting' | 'open' | 'closed'
  // order_id -> { agent_name, event_type, detail } for the most recent
  // event seen for that order. Lets OrderCard show "inventory: started"
  // live without a per-card fetch.
  const [liveAgentStatus, setLiveAgentStatus] = useState({});

  const wsRef = useRef(null);
  const reconnectTimerRef = useRef(null);

  const upsertOrder = useCallback((incoming) => {
    setOrders((prev) => {
      const idx = prev.findIndex((o) => o.id === incoming.id);
      if (idx === -1) {
        // New order: put it at the front so the most recent arrival is
        // immediately visible without the user having to scroll.
        return [incoming, ...prev];
      }
      const next = [...prev];
      next[idx] = incoming;
      return next;
    });
  }, []);

  useEffect(() => {
    let isMounted = true;

    // Step 1: REST fetch for whatever already exists.
    fetchOrders()
      .then((data) => {
        if (isMounted) setOrders(data);
      })
      .catch((err) => console.error("Failed to load initial orders:", err));

    // Step 2: open the live socket. Wrapped in a named function so we can
    // call it again from onclose to implement reconnection.
    function connect() {
      const ws = new WebSocket(WS_URL);
      wsRef.current = ws;

      ws.onopen = () => setConnectionStatus("open");

      ws.onmessage = (event) => {
        const message = JSON.parse(event.data);
        // The backend's WSMessage envelope always has {type, payload} —
        // see backend/app/models/schemas.py for the matching shape.
        switch (message.type) {
          case "order_created":
          case "order_updated":
            upsertOrder(message.payload);
            break;
          case "agent_event":
            setLiveAgentStatus((prev) => ({
              ...prev,
              [message.payload.order_id]: message.payload,
            }));
            break;
          default:
            // Unknown message types are ignored rather than thrown on —
            // this keeps the frontend forward-compatible if the backend
            // adds new event types later.
            break;
        }
      };

      ws.onclose = () => {
        setConnectionStatus("closed");
        // Schedule one reconnect attempt. We don't bound the number of
        // retries here since this is a small local dev tool — for a
        // production dashboard you'd add exponential backoff and a max
        // retry count.
        reconnectTimerRef.current = setTimeout(connect, RECONNECT_DELAY_MS);
      };

      ws.onerror = () => {
        // onerror is always followed by onclose firing, so we don't
        // duplicate reconnect logic here — just let onclose handle it.
        setConnectionStatus("closed");
      };
    }

    connect();

    return () => {
      isMounted = false;
      clearTimeout(reconnectTimerRef.current);
      wsRef.current?.close();
    };
  }, [upsertOrder]);

  return { orders, connectionStatus, liveAgentStatus };
}

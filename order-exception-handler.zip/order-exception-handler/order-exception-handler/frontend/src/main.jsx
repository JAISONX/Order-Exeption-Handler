import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import "./index.css";

// Standard React 18 entry point using createRoot (the React 17 ReactDOM.render
// API is deprecated). StrictMode helps catch accidental side effects in
// render (e.g. a component mutating state directly) during development —
// it has no effect on the production build.
createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

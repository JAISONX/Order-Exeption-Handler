import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Plain, minimal Vite config — this project doesn't need anything beyond
// the React plugin. Vite's dev server defaults to port 5173, which is why
// the backend's CORS_ORIGIN default (see backend/.env.example) points
// there.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
  },
});
